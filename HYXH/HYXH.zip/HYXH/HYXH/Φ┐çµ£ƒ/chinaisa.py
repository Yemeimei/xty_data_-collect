# -*- coding: utf-8 -*-
import json
import re

import scrapy
from lxml import etree
from scrapy.spiders import Spider

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class ChinaisaSpider(Spider):
    # 中国钢铁工业协会
    name = 'chinaisa'
    allowed_domains = ['chinaisa.org.cn']
    start_urls = ['http://www.chinaisa.org.cn/gxportal/EiService']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    def start_requests(self):
        for x in range(0, 9):
            data = {
                'service': 'ECTM02',
                'method': 'turnPage',
                'eiinfo': '{attr:{"templateUnitInsId":"0000000000010086","nodeId":"0000000000000495","nodeType":"c","":' + str(
                    x) + ',"currentPage":' + str(x + 1) + '},blocks:{}}'
            }
            yield scrapy.FormRequest(url=self.start_urls[0], formdata=data, callback=self.parse_item)
        for x in range(0, 6):
            data = {
                'service': 'ECTM02',
                'method': 'turnPage',
                'eiinfo': '{attr:{"templateUnitInsId":"0000000000010086","nodeId":"0000000000000212","nodeType":"c","":' + str(
                    x) + ',"currentPage":' + str(x + 1) + '},blocks:{}}'
            }
            yield scrapy.FormRequest(url=self.start_urls[0], formdata=data, callback=self.parse_item)
        for x in range(0, 1156):
            data = {
                'service': 'ECTM02',
                'method': 'turnPage',
                'eiinfo': '{attr:{"templateUnitInsId":"0000000000010086","nodeId":"0000000000000213","nodeType":"c","":' + str(
                    x) + ',"currentPage":' + str(x + 1) + '},blocks:{}}'
            }
            yield scrapy.FormRequest(url=self.start_urls[0], formdata=data, callback=self.parse_item)

    def parse_item(self, response):
        links = json.loads(response.text)
        html = etree.HTML(links['attr']['pageString'])
        urls = html.xpath("//a/@href")
        for url in urls:
            if not url.endswith("#"):
                url = 'http://www.chinaisa.org.cn' + url
                yield scrapy.Request(url=url, callback=self.parse2)

    def parse2(self, response):
        name = response.xpath("//td[@class='postion_text']/a[2]/text()").extract_first()
        title = response.xpath("//td[@class='subpage_inftitle_1']/text()").extract_first()

        p_time = response.xpath("//td[@class='subpage_inftitle_1time']/text()").extract()

        c_url = 'http://www.chinaisa.org.cn' + response.css("#mframe ::attr(src)").extract_first()

        meta = {
            'cname': name,
            'title': title,
            'p_time': p_time,
            # 'list_img': list_img
        }
        yield scrapy.Request(url=c_url, callback=self.parse3, meta={'item': meta})

    def parse3(self, response):
        item = HyxhItem()
        name = response.xpath("//table[@class='postion']/tbody/tr/td[@class='postion_text']/a[2]//text()").extract_first()
        if name == '行业要闻':
            item['ctype'] = 1
            content = response.css(".Section1 ").extract()
            txt = response.css(".Section1 ::text").extract()
            if response.encoding == 'ISO-8859-1':
                txt = txt.encode('ISO-8859-1').decode('GBK', 'ignore')

            meta = response.meta['item']
            lyurl = response.url
            lyname = '中国钢铁工业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = meta['cname']
            item['title'] = meta['title']
            if meta['cname']:
                item['p_time'] = get_times(str(meta['p_time']))
                item['source'] = meta['p_time'][0].split('关键字')[0].strip().replace(' \xa0&nbsp', '').split('：')[-1]
            else:
                item['p_time'] = ''
                item['source'] = ''
            item['content'] = ''.join(content)
            item['txt'] =txt
            item['spider_name'] = 'chinaisa'
            item['module_name'] = '行业新闻'
            yield item
        elif name == '统计概况':
            item['ctype'] = 2
            content = response.css(".Section1 ").extract()
            txt = response.css(".Section1 ::text").extract()
            if response.encoding == 'ISO-8859-1':
                txt = txt.encode('ISO-8859-1').decode('GBK', 'ignore')
            meta = response.meta['item']
            lyurl = response.url
            lyname = '中国钢铁工业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = meta['cname']
            item['title'] = meta['title']
            if meta['cname']:
                item['p_time'] = get_times(str(meta['p_time']))
                item['source'] = meta['p_time'][0].split('关键字')[0].strip().replace(' \xa0&nbsp', '').split('：')[-1]
            else:
                item['p_time'] = ''
                item['source'] = ''
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'chinaisa'
            item['module_name'] = '行业新闻'
            yield item
        else:
            item['ctype'] = 3
            content = response.css(".Section1 ").extract()
            txt = response.css(".Section1 ::text").extract()
            if response.encoding == 'ISO-8859-1':
                txt = txt.encode('ISO-8859-1').decode('GBK', 'ignore')

            meta = response.meta['item']
            lyurl = response.url
            lyname = '中国钢铁工业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = meta['cname']
            item['title'] = meta['title']
            if meta['cname']:
                item['p_time'] =get_times(str(meta['p_time']))
                item['source'] = meta['p_time'][0].split('关键字')[0].strip().replace(' \xa0&nbsp', '').split('：')[-1]
            else:
                item['p_time'] = ''
                item['source'] = ''
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'chinaisa'
            item['module_name'] = '行业协会'
            yield item