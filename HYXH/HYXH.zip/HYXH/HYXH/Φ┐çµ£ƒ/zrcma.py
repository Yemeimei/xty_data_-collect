# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem

# 此网页不可访问
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class ZrcmaSpider(CrawlSpider):
    # 浙江省轨道交通建设与管理协会
    name = 'zrcma'
    allowed_domains = ['zrcma.org.cn']
    start_urls = ['http://www.zrcma.org.cn/information/54.html']

    rules = (
        Rule(LinkExtractor(allow=r'Items/'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='detail']/p[1]/span[@id='rtitle']/text()").extract_first()
        p_time = response.xpath("//span[@id='pTime']/text()").extract_first()
        content = response.css(".entry ").extract()
        txt = response.css(".entry ::text").extract()
        item = HyxhItem()
        item['title'] = title
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] =get_times(p_time)
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'zrcma'
        item['module_name'] = '行业协会'
        yield item
