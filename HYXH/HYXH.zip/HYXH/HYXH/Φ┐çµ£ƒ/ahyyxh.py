# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class AhyyxhSpider(CrawlSpider):
    # 安徽省医药行业协会
    name = 'ahyyxh'
    allowed_domains = ['ahyyxh.cn']
    start_urls = ['http://ahyyxh.cn/portal.php?mod=list&catid=11',
                  'http://ahyyxh.cn/portal.php?mod=list&catid=23']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'aid=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='z']/a[4]/text()").extract_first()
        item = HyxhItem()
        if name == '行业动态':
            cname = 'ahhy'
            item['ctype'] = 1
            item['cname'] = cname
            title = response.xpath("//div[@class='h']/h1[@class='ph hm']/text()").extract_first()
            p_time = response.xpath("//div[@class='h']/p[@class='xg1']/text()").extract_first()
            source = response.xpath("//div[@class='h']/p[@class='xg1']/a[2]//text()").extract_first()
            content = response.css('#ct .d ').extract()
            txt = response.css('#ct .d ::text').extract()
            lyurl = response.url
            lyname = '安徽省医药行业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            appendix,appendix_name=get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            if source:
                item['source'] = source.strip()
            else:
                item['source'] = ''
            item['p_time'] = p_time.strip()
            txt = txt.strip()
            item['txt'] = txt
            item['content'] = ''.join(content)
            item['module_name'] ='行业协会'
            item['spider_name'] ='ahyyxh'
            yield item
        elif name == '行业综合数据':
            cname = 'ahsj'
            item['cname'] = cname
            item['ctype'] = 2
            title = response.xpath("//div[@class='h']/h1[@class='ph hm']/text()").extract_first()
            p_time = response.xpath("//div[@class='h']/p[@class='xg1']/text()").extract_first()
            source = response.xpath("//div[@class='h']/p[@class='xg1']/a[2]//text()").extract_first()
            content = response.css('#ct .d ').extract()
            txt = response.css('#ct .d ::text').extract()
            lyurl = response.url
            lyname = '中国材料研究学会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title.strip()
            txt = txt.strip()
            if source:
                item['source'] = source.strip()
            else:
                item['source'] = ''
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['p_time'] = get_times(p_time)
            item['txt'] = txt
            item['content'] =''.join(content)
            item['module_name'] = '行业协会'
            item['spider_name'] = 'ahyyxh'
            yield item

