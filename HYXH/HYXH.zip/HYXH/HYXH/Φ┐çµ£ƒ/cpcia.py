# -*- coding: utf-8 -*-
import json
import re

import scrapy

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CpciaSpider(scrapy.Spider):
    # 中国石油和化学工业联合会新闻动态
    name = 'cpcia'
    allowed_domains = ['cpcia.org.cn']
    start_urls = [f'http://www.cpcia.org.cn:5003/tianti-module-interface/interface/article/list?columnId=40288043661da1b701661dbbb3ce0004&currentPage={x}&pageSize=10'
                  for x in range(1, 5221)]
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    def parse(self, response):
        datas =json.loads(response.text)['data']['list']
        for data in datas:
            id = data['id']
            url = 'http://www.cpcia.org.cn/detail/' + id
            yield scrapy.Request(url, callback=self.parse_item)

    def parse_item(self, response):
        lyurl = response.url
        lyname = '中国石油和化学工业联合会'
        title = response.xpath("//div[@class='detail-container']/div[@class='header']/h1//text()").extract_first()
        p_time = response.xpath("//div[@class='others']/span[@class='word-overflow-1'][1]//text()").extract_first()
        source = response.xpath("//div[@class='others']/span[@class='word-overflow-1'][2]//text()").extract_first()
        content = response.css(".detail-container ").extract()
        txt = response.css(".detail-container ::text").extract()

        item = HyxhItem()
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title.strip()
        item['cname'] = '中国石油和化学工业联合会'
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['p_time'] = get_times(p_time)
        item['ctype'] = 1
        item['source'] = source
        item['txt'] = txt
        item['content'] = ''.join(content)
        item['spider_name'] = 'cpcia'
        item['module_name'] = '行业协会'
        yield item