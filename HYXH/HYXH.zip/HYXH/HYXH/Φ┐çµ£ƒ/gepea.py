# -*- coding: utf-8 -*-
import datetime
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class GepeaSpider(CrawlSpider):
    # 中国电子专用设备工业协会
    name = 'gepea'
    allowed_domains = ['cepea.com']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = ['http://www.cepea.com/news.asp?ProductClass_2=103&product_3=%D0%D0%D2%B5%B6%AF%CC%AC']

    rules = (
        Rule(LinkExtractor(allow=r'ProductClass_2=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'news\d+.htm$'), callback='parse_item', follow=True),
    )


    def parse_item(self, response):
        lyurl = response.url
        lyname = '中国电子专用设备工业协会'
        title = response.css("font ::text").extract_first()
        content = response.css("#table12 ").extract()
        txt = response.css("#table12 ::text").extract()
        item = HyxhItem()
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        p_time = lyurl.split("news")[-1].split('.')[0]
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['lyurl'] = lyurl
        item['ctype'] = 1
        item['source'] = ''
        item['p_time']=get_times(p_time)
        item['lyname'] = lyname
        item['cname'] = self.name
        item['title'] = title
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'gepea'
        item['module_name'] = '行业协会'
        yield item
