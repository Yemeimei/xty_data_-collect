# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class MakerbioSpider(CrawlSpider):
    # 成都市医疗器械行业协会
    name = 'makerbio'
    allowed_domains = ['makerbio.com']
    start_urls = ['http://www.makerbio.com/cdamei/list_page.asp?catid=news']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    rules = (
        Rule(LinkExtractor(allow=r'pg=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'catid=news$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[3]/h3/text()").extract_first()
        p_time = response.xpath("//div[3]/h3/div/text()").extract_first()
        content = response.css(".main_main ").extract()
        txt = response.css(".main_main ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '成都市医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['title'] = title
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] = get_times(p_time)
        item['source'] = ''
        item['ctype'] = 1
        item['spider_name'] = 'makerbio'
        item['module_name'] = '行业协会'
        yield item
