# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule
from scrapy_splash import SplashRequest

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times, delete_character


class ZjshipSpider(CrawlSpider):
    # 浙江省船舶行业协会
    name = 'zjship'
    allowed_domains = ['zjship.com.cn']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
    }
    start_urls = ['http://www.zjship.com.cn/zx/zx/', 'http://www.zjship.com.cn/dt/tj/']

    rules = (
        Rule(LinkExtractor(allow=r'', restrict_css=".more2"), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_css="#boxNewsList"), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='dmain2']/span[@class='homelink']/a[3]/text()").extract_first()
        title = response.xpath("//div[@id='boxNews']/div[@id='title']/text()").extract_first()
        p_time = response.xpath("//div[@id='boxNews']/div[@id='info']/text()").extract_first()
        content = response.css("#maininfo ").extract()
        txt = response.css("#maininfo ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '浙江省船舶行业协会'
        txt =delete_character(txt)
        if name == '行业统计':
            item['ctype'] = 3
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = name
            item['title'] = title
            item['txt'] = txt
            item['p_time'] = get_times(p_time)
            item['content'] = ''.join(content)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['source'] = ''
            item['spider_name'] = 'zjship'
            item['module_name'] = '行业协会'
            yield item
        elif name == '行业资讯':
            item['ctype'] = 1
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = name
            item['title'] = title
            item['txt'] = txt
            item['p_time'] = get_times(p_time)
            item['content'] = ''.join(content)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['source'] = ''
            item['spider_name'] = 'zjship'
            item['module_name'] = '行业协会'
            yield item