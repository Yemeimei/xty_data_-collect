# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class HyxhItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    ctype = scrapy.Field()
    lyurl = scrapy.Field()
    appendix = scrapy.Field()
    lyname = scrapy.Field()
    title = scrapy.Field()
    cname = scrapy.Field()
    p_time = scrapy.Field()
    source = scrapy.Field()
    content = scrapy.Field()
    image_urls = scrapy.Field()
    images = scrapy.Field()
    image_paths = scrapy.Field()
    filename = scrapy.Field()
    file_urls = scrapy.Field()
    files = scrapy.Field()
    file = scrapy.Field()
    appendix_name =scrapy.Field()
    txt =scrapy.Field()
    spider_name =scrapy.Field()
    module_name =scrapy.Field()
class CapcItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    cname = scrapy.Field()
    title = scrapy.Field()
    p_time = scrapy.Field()
    appendix = scrapy.Field()
    hit = scrapy.Field()
    origin = scrapy.Field()
    content = scrapy.Field()
    image_urls = scrapy.Field()
    images = scrapy.Field()
    image_paths = scrapy.Field()
    filename = scrapy.Field()
    file_urls = scrapy.Field()
    files = scrapy.Field()
    file = scrapy.Field()


class ScbiomedItem(scrapy.Item):
    cname = scrapy.Field()
    lyurl = scrapy.Field()
    lyname = scrapy.Field()
    appendix = scrapy.Field()
    title = scrapy.Field()
    p_time = scrapy.Field()
    abstract = scrapy.Field()
    content = scrapy.Field()
    image_urls = scrapy.Field()
    images = scrapy.Field()
    image_paths = scrapy.Field()
    filename = scrapy.Field()
    file_urls = scrapy.Field()
    files = scrapy.Field()
    file = scrapy.Field()

class QghynjItem(scrapy.Item):
    title = scrapy.Field()
    brief = scrapy.Field()
    file_urls = scrapy.Field()
    appendix = scrapy.Field()
    files = scrapy.Field()
    file = scrapy.Field()
    cname = scrapy.Field()

