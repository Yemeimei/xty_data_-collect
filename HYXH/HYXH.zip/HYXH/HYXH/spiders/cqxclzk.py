# -*- coding: utf-8 -*-
import scrapy
from lxml import etree

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments


class CqxclzkSpider(scrapy.Spider):
    name = 'cqxclzk'
    allowed_domains = ['cqxcl.cn']
    start_urls = [ 'http://www.cqxcl.cn/aspx/default/about.aspx?classid=236']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    def parse(self, response):
        htmls = response.css(".news a").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '重庆新材料专刊'
        item['cname'] = '新材料专刊'
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        for html in htmls:
            html = etree.HTML(html)
            list_file = html.xpath("//a/@href")
            filename = html.xpath("//a//text()")
            item['title'] = filename[0]
            item['p_time'] = ''
            item['source'] = ''
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['content'] ='http://www.cqxcl.cn/'+list_file
            item['txt'] = ''
            item['spider_name'] = 'cqxclzk'
            item['module_name'] = '行业协会'
            item['ctype'] = 1
            yield item