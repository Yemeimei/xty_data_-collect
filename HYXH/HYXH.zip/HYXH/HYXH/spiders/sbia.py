# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class SbiaSpider(CrawlSpider):
    # 上海市生物医药协会
    name = 'sbia'
    allowed_domains = ['sbia.org.cn']
    start_urls = [
        f'http://www.sbia.org.cn/news.aspx?newscateid=15&IntroCateId=15&BaseInfoCateId=15&cateid=15&ViewCateID=15&aboutidx=3&page={x}'
        for x in range(1, 116)]

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'NewsCateId=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='contenttext']/div[1]/span/text()").extract_first()
        p_time = response.xpath("//div[@class='contenttext']/div[2]/text()").extract()
        content = response.css(".article ").extract()
        txt = response.css(".article ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '上海市生物医药协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = self.name
        item['title'] = title
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['ctype'] = 1
        item['p_time'] =get_times(p_time)
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'samd'
        item['module_name'] = '行业协会'
        yield item
