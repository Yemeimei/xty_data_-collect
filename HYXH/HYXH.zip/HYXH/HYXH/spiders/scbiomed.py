# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import ScbiomedItem, HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class ScbiomedSpider(CrawlSpider):
    # 四川生物医药技术创新平台
    name = 'scbiomed'
    allowed_domains = ['scbiomed.com']
    start_urls = ['http://www.scbiomed.com/news/NewsList_173.html']

    rules = (
        Rule(LinkExtractor(allow=r'NewsList_173_\d+.html$'), follow=True),
        Rule(LinkExtractor(allow=r'\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        try:
            title = response.xpath("//ul[@class='r4']/li[@class='li1']/text()").extract_first()
            p_time = response.xpath(
                "//div[@id='wid']/div[@class='rig']/ul[@class='r4']/li[@class='li2']/text()").extract()
            content = response.css('.rig').extract()
            txt = response.css('.rig  ::text').extract()
            item = HyxhItem()
            lyurl = response.url
            lyname = '四川生物医药技术创新平台'
            content = re.sub(r'\r+', '', ''.join(content[10:]))
            content = re.sub(r'\n+', '', content)
            content = re.sub(r'\t+', '', content)
            content = re.sub(r'(\u3000)+', '', content)
            content = re.sub(r'\xa0', '', content)
            content = re.sub(r' ', '', content)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            if title:
                item['title'] = title.strip()
            else:
                item['title'] = ''
            item['cname'] = self.name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['content'] = content
            item['source'] = p_time[1].split('来源：')[1].split("作者")[0]
            item['ctype'] = 1
            item['p_time'] =get_times(p_time)
            item['spider_name'] = 'scbiomed'
            item['module_name'] = '行业协会'
            yield item
        except:
            pass
