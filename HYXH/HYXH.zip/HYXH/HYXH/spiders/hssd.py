# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class HssdSpider(CrawlSpider):
    # 山东省海洋工程咨询协会
    name = 'hssd'
    allowed_domains = ['hssd.gov.cn']
    start_urls = [f'http://www.hssd.gov.cn/pub/hygczxxh/xhxw/index_{x}.html' for x in range(1, 5)]
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    def start_requests(self):
        url = 'http://www.hssd.gov.cn/pub/hygczxxh/xhxw/index.html'
        yield self.make_requests_from_url(url)
        for url in self.start_urls:
            yield self.make_requests_from_url(url)

    rules = (
        Rule(LinkExtractor(allow=r'\d+/t\d+_\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='title']//text()").extract()
        p_time = response.xpath("//span[@class='date']//text()").extract_first()
        content = response.css(".TRS_Editor ").extract()
        txt = response.css(".TRS_Editor ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '山东省海洋工程咨询协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = self.name
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title[1].strip()
        item['p_time'] = get_times(p_time)
        item['source'] = ''
        item['ctype'] = 1
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'hssd'
        item['module_name'] = '行业协会'
        yield item
