# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class JamiaSpider(CrawlSpider):
    # 江苏省新材料产业协会
    name = 'jamia'
    allowed_domains = ['jamia.org.cn']
    start_urls = ['http://jamia.org.cn/index.php?g=&m=contents&a=index&term_id=31',
                  'http://jamia.org.cn/index.php?g=&m=contents&a=index&term_id=37']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'term_id=31&id=\d+$'), callback='parse_item', follow=True),
        Rule(LinkExtractor(allow=r'a=info&id=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        item = HyxhItem()
        name = response.xpath("//td[1]/table[@class='jamia_tittle_01_bk']/tbody/tr[1]/td[@class='list_left']//text()").extract_first()
        if name:
            item['ctype'] = 1
            name = '新闻动态'
        else:
            item['ctype'] = 3
            name = '分析报告'
        title = response.xpath("//tbody/tr[2]/td/table/tbody/tr[1]/td/h2/text()").extract_first()
        p_time = response.xpath("//tr[2]/td/table/tbody/tr[3]/td/div/text()").extract_first()
        content = response.css(" tbody ").extract()
        txt = response.css(" tbody ::text").extract()
        item['cname'] = name
        lyurl = response.url
        lyname = '江苏省医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        source = txt.split("。")[-1]
        item['source'] = source
        if source:
            item['source'] = source.split('：')[-1]
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title
        item['p_time'] = get_times(p_time)
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'jamia'
        item['module_name'] = '行业协会'
        yield item


