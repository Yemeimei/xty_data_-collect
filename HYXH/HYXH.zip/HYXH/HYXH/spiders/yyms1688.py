# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times, delete_character


class Yyms1688Spider(CrawlSpider):
    # 湖南新材料产业协会
    name = 'yyms1688'
    allowed_domains = ['yyms1688.com']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
    }
    start_urls = ['http://www.yyms1688.com/plus/list.php?tid=37', 'http://www.yyms1688.com/plus/list.php?tid=39']

    rules = (
        Rule(LinkExtractor(allow=r'aid=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='dynamic_list']/h2/text()").extract_first()
        item = HyxhItem()
        title = response.xpath("//div[@class='content_txt']/h2/text()").extract_first()
        p_time = response.xpath("//div[@class='tis']/span[1]/text()").extract_first()
        source = response.xpath("//div[@class='tis']/span[2]/text()").extract_first()
        content = response.css(".main ").extract()
        txt = response.css(".main ::text").extract()
        lyurl = response.url
        lyname = '湖南新材料产业协会'
        txt = delete_character(txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = name
        item['title'] = title
        item['p_time'] = get_times(p_time)
        item['source'] = source
        item['content'] =''.join(content)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['appendix'] = appendix
        item['txt'] = txt
        item['spider_name'] = 'xamd'
        item['module_name'] = '行业协会'
        yield item