# -*- coding: utf-8 -*-
import re

import scrapy
from lxml import etree
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CqxclSpider(CrawlSpider):
    # 重庆市新材料产业联合会
    name = 'cqxcl'
    allowed_domains = ['cqxcl.cn']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = [
        'http://www.cqxcl.cn/aspx/default/newslist.aspx?classid=200',
    ]

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_xpaths="//ul[@class='newslist']/li"), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='nntitle']/p[1]/strong/text()").extract_first()
        p_time = response.xpath("//div[@class='nntitle']/p[3]/span/text()").extract_first()
        content = response.css(".newscontent ").extract()
        txt = response.css(".newscontent ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '重庆市新材料产业联合会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = '产业新闻'
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['source'] = p_time.split('\xa0')[0].split("：")[-1]
        item['p_time'] =get_times(p_time)
        item['ctype'] = 1
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'cqxcl'
        item['module_name'] = '行业协会'
        yield item

