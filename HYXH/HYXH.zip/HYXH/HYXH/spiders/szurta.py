# -*- coding: utf-8 -*-
import re

import scrapy
from lxml import etree
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class SzurtaSpider(CrawlSpider):
    # 深圳市城市轨道交通协会
    name = 'szurta'
    allowed_domains = ['szurta.org']
    start_urls = ['http://www.szurta.org/col.jsp?id=103']

    rules = (
        Rule(LinkExtractor(allow=r'pageno=\d+$'), callback='parse2', follow=True),
        # Rule(LinkExtractor(allow=r'_np=\d+\_\d+$'),  callback='parse_item',follow=True),
    )

    def parse2(self, response):
        htmls = response.css("#newsList307 div").extract()
        # print(htmls)
        for html in htmls:
            # print(html)
            html = etree.HTML(html)
            # title = html.xpath("//td[@class='J_newsTitle']//a//text()")[0]
            # urls = html.xpath("//td[@class='J_newsTitle']//a/@href")
            # p_time = html.xpath("//td[@class='newsCalendar']//a//text()")
            # print(urls, p_time)
            urls = html.xpath("//a/@href")
            p_time = html.xpath("//a//text()")
            # print(urls, p_time)
            if p_time:
                p_time = p_time[-1]
                url = urls[0]
                yield scrapy.Request(response.urljoin(url), callback=self.parse_item, meta={'p_time': p_time})

    def parse_item(self, response):
        title = response.xpath("//div[@class='newsDetail']/h1[@class='title']/text()").extract_first()
        source = response.xpath("//div[@class='sourceInfo']/span[@class='sourceInfoContent'][1]/text()").extract_first()
        content = response.css(".newsDetail ").extract()
        txt = response.css(".newsDetail ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '深圳市城市轨道交通协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        if source.startswith('来源'):
            item['source'] = source.split("：")[-1]
        else:
            item['source'] = ''
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title
        item['p_time'] = get_times( response.meta['p_time'])
        item['ctype'] = 1
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'szurta'
        item['module_name'] = '行业协会'
        yield item
