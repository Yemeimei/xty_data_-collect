# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from lxml import etree

from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CamdiSpider(CrawlSpider):
    # 中国医疗器械行业协会
    name = 'camdi'
    allowed_domains = ['camdi.org']
    start_urls = ['http://www.camdi.org/news/list/50%2C63%2C0/p2',
                  'http://www.camdi.org/news/list/51%2C96%2C97/p2',
                  'http://www.camdi.org/news/list/51,96,98'
                  ]
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    rules = (
        Rule(LinkExtractor(allow=r'', restrict_xpaths="//ul[@class='pagination']/li"), callback='parse', follow=True),
        # Rule(LinkExtractor(allow=r'', restrict_xpaths="//div[@class='news-v3-in-sm no-padding']/h3"),
        #      callback='parse_item', follow=True),
    )

    def parse(self, response):
        name = response.css(".col-md-9 .headline h2::text").extract_first()
        print(name)
        urls = response.xpath("//div[@class='news-v3-in-sm no-padding']/h3/a/@href").extract()
        ctype = response.xpath(
            "//div[@class='col-md-9 col-lg-9 news-list news-text-list']/div[@class='headline headline-md mb40']/h2//text()").extract_first()
        meta = {
            'cname': name,
            'ctype': ctype
        }
        for url in urls:
            yield scrapy.Request(url=response.urljoin(url), callback=self.parse_item, meta={'item': meta})

    def parse_item(self, response):
        item = HyxhItem()
        cname = response.meta['item']['cname']
        ctype = response.meta['item']['ctype']
        title = response.xpath("//div[@class='news-v3-in']/h2/text()").extract_first()
        p_time = response.xpath("//li[@class='pull-left']/text()").extract_first()
        content = response.css("#description ").extract()
        txt = response.css("#description ::text").extract()
        lyurl = response.url
        lyname = '中国医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        if ctype == '行业新闻':
            item['ctype'] = 1
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['source'] = txt.split('来源：')[-1].strip()
            item['cname'] = cname
            item['title'] = title
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['p_time'] = get_times(str(p_time))
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] ='camdi'
            item['module_name'] ='行业协会'
            yield item

        elif ctype == '行业发展分析与预测':
            item['ctype'] = 3
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['source'] = txt.split('来源：')[-1].strip()
            item['cname'] = cname
            item['title'] = title
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['p_time'] = get_times(str(p_time))
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'camdi'
            item['module_name'] = '行业协会'
            yield item

        elif ctype == '行业数据统计与分析':
            item['ctype'] = 2
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['source'] = txt.split('来源：')[-1].strip()
            item['cname'] = cname
            item['title'] = title
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['p_time'] =get_times(str(p_time))
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'camdi'
            item['module_name'] = '行业协会'
            yield item
