# -*- coding: utf-8 -*-
import re
from copy import deepcopy

import scrapy
from lxml import etree
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class NbamdiSpider(CrawlSpider):
    # 宁波市医疗器械行业协会
    name = 'nbamdi'
    allowed_domains = ['nbamdi.com']
    start_urls = ['http://www.nbamdi.com/news/list/77-27-1.html']

    rules = (
        Rule(LinkExtractor(allow=r'news/\d+-\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        print(response.url)
        title = response.xpath("//div[@class='nr_cont1 ']/h2/text()").extract_first()
        p_time = response.xpath("//div[@class='tittle_j']/text()").extract_first()
        content = response.css(".main_content ").extract()
        txt = response.css(".main_content ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '宁波市医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = self.name
        item['ctype'] = 1
        item['txt'] = txt
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] = get_times(p_time)
        item['source'] = ''
        item['content'] = ''.join(content)
        item['spider_name'] = 'nbamdi'
        item['module_name'] = '行业协会'
        yield item

