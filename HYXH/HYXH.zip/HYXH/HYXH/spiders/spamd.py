# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class SpamdSpider(CrawlSpider):
    # 陕西省医疗器械行业协会
    name = 'spamd'
    allowed_domains = ['spamd.org.cn']
    start_urls = [f'http://www.spamd.org.cn/news/2/#c_news_list-15416574840437902-{x}' for x in range(1, 3)]

    rules = (
        Rule(LinkExtractor(allow=r'/news/\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//h1[@class='e_title e_head-000 p_head ']/div[@class='font']//text()").extract()
        p_time = response.xpath(
            "//div[@class='e_title e_AssistInfo-001  p_time']/div[@class='font']/text()").extract_first()
        content = response.css(".js_infoDetail_content ").extract()
        txt = response.css(".js_infoDetail_content ::text").extract()
        source = response.xpath("//div[@class='e_box e_box-000 p_FromBox  ']/div[@class='e_title e_AssistInfo-001 p_from']//text()").extract_first()
        item = HyxhItem()
        lyurl = response.url
        lyname = '陕西省医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title[1].strip()
        item['cname'] = self.name
        item['source'] = source
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] = get_times(p_time)
        item['ctype'] = 1
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'spamd'
        item['module_name'] = '行业协会'
        yield item
