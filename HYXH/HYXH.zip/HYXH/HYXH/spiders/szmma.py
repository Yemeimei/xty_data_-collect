# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class SzmmaSpider(CrawlSpider):
    # 深圳市新材料行业协会
    name = 'szmma'
    allowed_domains = ['szmma.org']
    start_urls = ['http://www.szmma.org/portal/index/products.html']

    rules = (
        Rule(LinkExtractor(allow=r'/id/\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        # print(response.url)
        title = response.xpath("//div[@class='detai_bt']/h3/text()").extract_first()
        p_time = response.xpath("//div[@class='detai_bt']/div[@class='info']/span/text()").extract_first()
        content = response.css(".content ").extract()
        txt = response.css(".content ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '深圳市新材料行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = self.name
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] = get_times(p_time)
        item['content'] = ''.join(content)
        item['source'] = ''
        item['ctype'] = 1
        item['txt'] = txt
        item['spider_name'] = 'szmma'
        item['module_name'] = '行业协会'
        yield item
