# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CMrsSpider(CrawlSpider):
    # 中国材料研究学会
    name = 'c_mrs'
    allowed_domains = ['c-mrs.org.cn']
    start_urls = ['http://www.c-mrs.org.cn/cn/news_list.asp?newclassid=20']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        'DOWNLOADER_MIDDLEWARES': {
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
    }

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_xpaths="//div[@class='list lianjie liebiao']"), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class=' neirong-l bk']/h1/text()").extract_first()
        p_time = response.xpath("//div[@class='newsinfo']/text()").extract()
        content = response.css(".ContentLabel ").extract()
        txt = response.css(".ContentLabel ::text").extract()
        source = response.xpath("//div[@class=' neirong-l bk']/div[@class='newsinfo']//text()").extract_first()
        source = source.split('  ')[1].split("：")[-1]
        item = HyxhItem()
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['ctype'] = 1
        lyurl = response.url
        lyname = '中国材料研究学会'
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = self.name
        item['source'] =''.join(source)
        txt = txt.strip()
        item['p_time'] = get_times(str(p_time))
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] ='c_mrs'
        item['module_name'] ='行业协会'
        yield item