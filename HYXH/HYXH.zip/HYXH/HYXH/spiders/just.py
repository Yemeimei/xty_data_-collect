# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class JustSpider(CrawlSpider):
    # 江苏省船舶工业行业协会
    name = 'just'
    allowed_domains = ['just.edu.cn']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = ['http://jasi.just.edu.cn/xwdt/list.htm',
                  'http://jasi.just.edu.cn/_s100/sjtj/list.psp',
                  'http://jasi.just.edu.cn/_s100/xyxx/list.psp'
                  ]



    rules = (
        Rule(LinkExtractor(allow=r'', restrict_css=".nei_left"), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_css=".page_nav"), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_css=".posts"), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='top']/a[2]/text()").extract_first()
        title = response.xpath("//div[@id='nei_right']/div[2]/div[@id='news_title']/text()").extract_first()
        p_time = response.xpath("//div[@id='nei_right']/div[2]/div[@id='news_date']/text()").extract_first()
        content = response.css(".nei ").extract()
        txt = response.css(".nei ::text").extract()
        item = HyxhItem()
        if name == '新闻动态':
            item['ctype'] = 1
        elif name == '数据统计':
            item['ctype'] = 2
        else:
            item['ctype'] = 3
        lyurl = response.url
        lyname = '江苏省船舶工业行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = name
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title
        item['p_time'] =get_times(p_time)
        item['source'] = ''
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'just'
        item['module_name'] = '行业协会'
        yield item
