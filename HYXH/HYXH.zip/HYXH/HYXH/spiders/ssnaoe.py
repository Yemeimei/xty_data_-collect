# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments


class SsnaoeSpider(CrawlSpider):
    # 上海市船舶与海洋工程学会
    name = 'ssnaoe'
    allowed_domains = ['ssnaoe.org']
    start_urls = ['http://www.ssnaoe.org/shcbyhy/node3/n6/index.html']

    rules = (
        Rule(LinkExtractor(allow=r'index\d+.html$'), follow=True),
        Rule(LinkExtractor(allow=r'u1ai\d+.html$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("/html/body/div[@class='main2 ma clear']/div[@class='breadnav']/text()").extract_first()
        print(name)
        title = response.xpath("//div[@class='main2 ma clear']/h2/text()").extract_first()
        p_time = response.xpath("//span[@class='riqi_1'][1]/text()").extract_first()
        source = response.xpath("/html/body/div[@class='main2 ma clear']/span[@class='riqi_1'][2]//text()").extract_first()
        content = response.css(".para ").extract()
        txt = response.css(".para ::text").extract()
        item = HyxhItem()
        item['cname'] = self.name
        lyurl = response.url
        lyname = '上海市船舶与海洋工程学会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title
        p_time = re.findall('\d+', p_time.split("：")[-1])
        item['p_time'] = '-'.join(p_time)
        if source:
            item['source'] = source.split(":")[-1]
        else:
            item['source'] = source
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'ssnaoe'
        item['module_name'] = '行业协会'
        yield item
