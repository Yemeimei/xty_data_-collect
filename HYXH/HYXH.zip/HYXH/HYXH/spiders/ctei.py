# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CteiSpider(CrawlSpider):
    # 中国纺织工业联合会
    name = 'ctei'
    allowed_domains = ['ctei.cn']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = ['http://news.ctei.cn/domestic/gnzx/',
                  'http://news.ctei.cn/brand/gnpp/',
                  'http://news.ctei.cn/Technology/gndt/',
                  'http://news.ctei.cn/apparel/gnfz/',
                  'http://news.ctei.cn/policy/hyzc/',
                  'http://news.ctei.cn/internal/gjzx/',
                  'http://news.ctei.cn/apparel/gjfz/',
                  'http://news.ctei.cn/trade/gjmy/',
                  'http://news.ctei.cn/policy/gwzc/',
                  'http://news.ctei.cn/Technology/gjdt/']

    def start_requests(self):
        for x in range(1, 18):
            if x == 1:
                url = 'http://news.ctei.cn/Technology/gjdt/index.html'
            else:
                url = f'http://news.ctei.cn/Technology/gjdt/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url = 'http://news.ctei.cn/apparel/gjfz/index.html'
            else:
                url = f'http://news.ctei.cn/apparel/gjfz/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url = 'http://news.ctei.cn/trade/gjmy/index.html'
            else:
                url = f'http://news.ctei.cn/trade/gjmy/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url = 'http://news.ctei.cn/internal/gjzx/index.html'
            else:
                url = f'http://news.ctei.cn/internal/gjzx/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url = 'http://news.ctei.cn/Technology/gndt/index.html'
            else:
                url = f'http://news.ctei.cn/Technology/gndt/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/apparel/gnfz/index.html'
            else:
                url = f'http://news.ctei.cn/apparel/gnfz/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/brand/gnpp/index.html'
            else:
                url = f'http://news.ctei.cn/brand/gnpp/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/policy/gwzc/index.html'
            else:
                url = f'http://news.ctei.cn/policy/gwzc/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/policy/hyzc/index.html'
            else:
                url = f'http://news.ctei.cn/policy/hyzc/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/trade/jckxx/index.html'
            else:
                url = f'http://news.ctei.cn/trade/jckxx/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 12):
            if x == 1:
                url ='http://news.ctei.cn/domestic/zx_gn_jjyx/index.html'
            else:
                url = f'http://news.ctei.cn/domestic/zx_gn_jjyx/index_{x}.html'
            yield self.make_requests_from_url(url)
        for x in range(1, 18):
            if x == 1:
                url ='http://news.ctei.cn/domestic/gnzx/index.html'
            else:
                url = f'http://news.ctei.cn/domestic/gnzx/index_{x}.html'
            yield self.make_requests_from_url(url)


    rules = (
        Rule(LinkExtractor(allow=r'\d+/t\d+_\d+.htm$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.css(".CurrChnlCls ::text").extract()
        title = response.xpath("//span[@class='erjibt']/text()").extract_first()
        p_time = response.css(".infobian ::text").extract()
        content = response.css(".TRS_Editor ").extract()
        txt = response.css(".TRS_Editor ::text").extract()
        item = HyxhItem()
        if name[-1] == '经济运行':
            item['ctype'] = 3
        else:
            item['ctype'] = 1
        lyurl = response.url
        lyname = '中国纺织工业联合会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = name[-1]
        item['source'] = txt.split('。', -1)[-1]
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['title'] = title.strip()
        item['p_time'] =get_times(str(p_time))
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'ctei'
        item['module_name'] = '行业协会'
        yield item

