# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class XclcySpider(CrawlSpider):
    # 浙江省新材料产业协会
    name = 'xclcy'
    allowed_domains = ['xclcy.com']
    start_urls = ['http://www.xclcy.com/info/list.php?catid=2374&page=1',
                  'http://www.xclcy.com/info/list.php?catid=2380']

    rules = (
        Rule(LinkExtractor(allow=r'', restrict_xpaths="//div[@class='pages']"), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_xpaths="//ul[@class='ind_all_news4']"), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        print(response.url)
        name = response.xpath("//div[@class='crumbs mt-10']/a[3]/text()").extract_first()
        print(name)
        item = HyxhItem()
        if name == '行业分析':
            item['ctype'] = 3
        else:
            item['ctype'] = 1
        item['cname'] = name
        title = response.xpath("//div[@class='inf_content']/div[@class='titles']/h1/text()").extract_first()
        p_time = response.xpath("//div[@class='titles']/p[@class='fl']/text()").extract()
        content = response.css("#article").extract()
        txt = response.css("#article ::text").extract()
        lyurl = response.url
        lyname = '浙江省新材料产业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title.split(' ')[-1]
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] = get_times(p_time)
        source = content.split('。', -1)[-1]
        item['source'] = source
        if len(source) >20:
            item['source'] = ''
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'xamd'
        item['module_name'] = '行业协会'
        yield item
