# -*- coding: utf-8 -*-
import re

import scrapy
from lxml import etree
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments


class SamdSpider(CrawlSpider):
    # 深圳市医疗器械行业协会
    name = 'samd'
    allowed_domains = ['samd.org.cn']
    start_urls = ['http://www.samd.org.cn/news/news.aspx?typeid=11&page=1']

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'news_\d+.aspx\?typeid=11$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@id='rightcol']/h2[@class='titles']/text()").extract_first()
        content = response.css('#rightcol ').extract()
        txt = response.css('#rightcol ::text').extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '深圳市医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = self.name
        item['title'] = title
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['ctype'] = 1
        item['p_time'] = ''
        item['source'] = ''
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'samd'
        item['module_name'] = '行业协会'
        yield item

