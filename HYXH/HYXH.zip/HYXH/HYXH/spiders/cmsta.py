# -*- coding: utf-8 -*-
import re
from urllib.parse import quote, unquote
import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CmstaSpider(CrawlSpider):
    # 中国物资储运协会
    name = 'cmsta'
    allowed_domains = ['cmsta.org']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = ['http://www.cmsta.org/page441?article_category=41', 'http://www.cmsta.org/page423?article_category=70&brd=1']

    def start_requests(self):
        for x in range(1, 26):
            url = f'http://www.cmsta.org/index.php?_m=article_list&_a=get_page&article_category=41&layer_id=layerE009D58E988DB597CE5781846D55F3A6&page={x}&article_category_more=41'
            yield self.make_requests_from_url(url)
        for y in range(1, 3):
            url = f'http://www.cmsta.org/index.php?_m=article_list&_a=get_page&article_category=70&layer_id=layer8115675EE7CAF0B2271C2282B7D5E627&page={x}&article_category_more=70'
            yield self.make_requests_from_url(url)
    rules = (
        Rule(LinkExtractor(allow=r'article_id=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//span[@class='breadcrumbtext'][2]/a//text()").extract_first()
        title = response.xpath("//div[@class='artdetail_title']//text()").extract_first()
        p_time = response.xpath("//span[@class='detail_head_title pub_txt_span']//text()").extract()
        source = response.xpath("//span[@class='detail_head_title org_txt_span']//text()").extract()
        content = response.css(".artview_detail").extract()
        txt = response.css(".artview_detail ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '中国物资储运协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        if name == '行业前沿':
            item['ctype'] = 1
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            item['cname'] = name
            item['p_time'] = get_times(str(p_time))
            item['source'] = ''.join(source).split(":")[-1]
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cmsta'
            item['module_name'] = '行业协会'
            yield item
        else:
            item['ctype'] = 2
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            item['cname'] = name
            item['p_time'] = get_times(str(p_time))
            item['source'] = ''.join(source).split(":")[-1]
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cmsta'
            item['module_name'] = '行业协会'
            yield item