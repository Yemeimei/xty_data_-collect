# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CmbaSpider(CrawlSpider):
    # 中国生物医药技术协会
    name = 'cmba'
    allowed_domains = ['cmba.org.cn']
    start_urls = ['http://www.cmba.org.cn/common/index.aspx?nodeid=155']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    rules = (
        Rule(LinkExtractor(allow=r'pagesize=\d+&pagenum=\d+'), follow=True),
        Rule(LinkExtractor(allow=r'contentid=\d+'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='content_kk']/h2/text()").extract_first()
        p_time = response.xpath("//div[@class='author_k']/div[@class='acc_right']/text()").extract_first()
        source = response.xpath("//div[@class='acc_content']/p[last()]/span/text()").extract_first()
        content = response.css(".acc_content").extract()
        txt =  response.css(".acc_content ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '中国生物医药技术协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['lyurl'] = lyurl
        item['ctype'] = 1
        item['lyname'] = lyname
        item['cname'] = self.name
        item['source'] = source.split("：")[-1].split("）")[0]
        item['title'] = title
        item['p_time'] = get_times(p_time)
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'cmba'
        item['module_name'] = '行业协会'
        yield item

