# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import CapcItem, HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CapcSpider(CrawlSpider):
    # 浙江省生物医药产业创新
    name = 'capc'
    allowed_domains = ['capc.org.cn']
    start_urls = [f'http://www.capc.org.cn/index.html/list-e0978628ef66490a916a3b66017bdd39.html?pageNo={x}&pageSize=4' for x in range(1, 146)]
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    rules = (
        Rule(LinkExtractor(allow=r'view-.*?.html'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='list_a']/div[@class='addrbar fl']/a[2]//text()").extract_first()
        if name == '行业信息':
            item = HyxhItem()
            title = response.xpath("//div[@class='fl rightb']/div[@class='list_a']/h2/text()").extract_first()
            p_time = response.xpath("//div[@class='mor']/font[@class='time']/text()").extract_first()
            source = response.xpath("//div[@class='mor']/label[@class='layuan']/text()").extract_first()
            content = response.css(".newxw ").extract()
            txt = response.css(".newxw ::text").extract()
            lyurl = response.url
            lyname = '浙江省生物医药产业创新'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['txt'] = txt
            item['content'] = ''.join(content)
            item['cname'] = self.name
            item['title'] = title
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['p_time'] = get_times(p_time)
            item['source'] = source
            item['spider_name'] = 'capc'
            item['module_name'] = '行业协会'
            item['ctype'] = ''
            yield item