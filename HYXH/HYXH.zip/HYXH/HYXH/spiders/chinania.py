# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class ChinaniaSpider(CrawlSpider):
    # 中国有色金属工业协会
    name = 'chinania'
    allowed_domains = ['chinania.org.cn']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    start_urls = ['http://www.chinania.org.cn/html/yaowendongtai/guoneixinwen/',
                  'http://www.chinania.org.cn/html/guojihezuo/guojixinwen/',
                  'http://www.chinania.org.cn/html/kuangchanziyuan/',
                  'http://www.chinania.org.cn/html/hangyeyanjiu/',
                  'http://www.chinania.org.cn/html/hangyetongji/tongji/']

    rules = (
        Rule(LinkExtractor(allow=r'', restrict_css=".text-c"), follow=True),
        Rule(LinkExtractor(allow=r'', restrict_css=".list "), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='crumbs']/a[2]//text()").extract_first()
        title = response.xpath(
            "/html/body/div[@class='main']/div[@class='col-auto']/div[@id='Article']/h1//text()").extract_first()
        p_time = response.xpath(
            "/html/body/div[@class='main']/div[@class='col-auto']/div[@id='Article']/h1/span//text()").extract_first()
        source = response.xpath("//div[@id='Article']/h1/span[1]/a//text()").extract_first()
        content = response.css(".content ").extract()
        txt = response.css(".content ::text").extract()
        item = HyxhItem()
        if name == '行业研究' or name == '行业统计':
            item['ctype'] = 3
            lyurl = response.url
            lyname = '中国有色金属工业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['title'] = title
            if p_time:
                item['p_time'] = get_times(p_time)
                item['source'] = source
            else:
                item['p_time'] = ''
                item['source'] = ''
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'chinania'
            item['module_name'] = '行业新闻'
            yield item
        else:
            item['ctype'] = 1
            lyurl = response.url
            lyname = '中国有色金属工业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['title'] = title
            if p_time:
                item['p_time'] = get_times(p_time)
                item['source'] = source
            else:
                item['p_time'] = ''
                item['source'] = ''
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'chinania'
            item['module_name'] = '行业协会'
            yield item