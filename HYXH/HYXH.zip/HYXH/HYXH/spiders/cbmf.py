# -*- coding: utf-8 -*-
import re

import scrapy
from lxml import etree

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CbmfSpider(scrapy.Spider):
    # 中国建筑材料联合会
    name = 'cbmf'
    allowed_domains = ['cbmf.org']
    start_urls = ['http://www.cbmf.org/cbmf/xydt/xyxx/index.html',
                  'http://www.cbmf.org/cbmf/xylj/qyjd/index.html',
                  'http://www.cbmf.org/cbmf/xylj/fzdt57/index.html',
                  'http://www.cbmf.org/cbmf/xyyj53/jcfzyj28/index.html',
                  'http://www.cbmf.org/cbmf/xyyj53/jckjfzzl/index.html',
                  'http://www.cbmf.org/cbmf/xyyj53/tsyxb/index.html']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    def start_requests(self):
        url = 'http://www.cbmf.org/cbmf/xyyj53/jcfzyj28/index.html'
        yield self.make_requests_from_url(url)
        url = 'http://www.cbmf.org/cbmf/xyyj53/jckjfzzl/index.html'
        yield self.make_requests_from_url(url)
        url = 'http://www.cbmf.org/cbmf/xyyj53/tsyxb/index.html'
        yield self.make_requests_from_url(url)
        for x in range(1, 37):
            url = f'http://www.cbmf.org/eportal/ui?pageId=6323947&currentPage={x}&moduleId=de098b6030da45c088b7b761b463be4a&staticRequest=yes'
            yield self.make_requests_from_url(url)
        for x in range(1, 26):
            url = f'http://www.cbmf.org/eportal/ui?pageId=6357435&currentPage={x}&moduleId=ff1829550abd43cb80b6ea0676a22eba&staticRequest=yes'
            yield self.make_requests_from_url(url)
        for x in range(1, 8):
            url = f'http://www.cbmf.org/eportal/ui?pageId=6357438&currentPage={x}&moduleId=ff09bc2d54ad4f2e969de7eb774910cc&staticRequest=yes'
            yield self.make_requests_from_url(url)



    def parse(self, response):
        url = response.url
        if url.endswith('html'):
            urls = response.css(".left_zhong a::attr(href)").extract()
            for url in urls:
                yield scrapy.Request(response.urljoin(url), callback=self.parse2)
        else:
            urls = response.css(".news-main a::attr(href)").extract()
            for url in urls:
                yield scrapy.Request(response.urljoin(url), callback=self.parse_item)

    def parse2(self, response):
        htmls = response.css(".news-main li").extract()
        for html in htmls:
            html = etree.HTML(html)
            url = html.xpath('//a/@href')[0]
            if url.endswith("pdf"):
                item = HyxhItem()
                filename = html.xpath("//a/text()")
                p_time = html.xpath("//span//text()")[0]
                item['lyname'] = '中国建筑材料联合会'
                item['lyurl'] = response.url
                item['p_time'] =get_times(p_time)
                item['source'] = ''
                item['content'] = ''
                appendix, appendix_name = get_attachments(response)
                item['appendix'] = appendix
                item['appendix_name'] = appendix_name
                item['title'] = filename[0]
                item['ctype'] = 3
                item['txt'] = ''
                item['spider_name'] = 'cbmf'
                item['module_name'] = '行业新闻'
                yield item
            else:
                yield scrapy.Request(response.urljoin(url), callback=self.parse_item)
        urls = response.css(".pagingNormal ::attr(tagname)").extract()
        if urls:
            urls = list(set(urls))
            for url in urls:
                yield scrapy.Request(response.urljoin(url), callback=self.parse2)





    def parse_item(self, response):
        lyurl = response.url
        item = HyxhItem()
        name = response.xpath("//a[@class='SkinObject'][3]/text()").extract_first()
        if name == '行业信息':
            item['ctype'] = 1
            # lyname = '中国建筑材料联合会'
            title = response.xpath("//table[@class='normal']/tbody/tr[1]/td/h1//text()").extract_first()
            res = response.xpath("//table[@class='normal']/tbody/tr[3]/td//text()").extract()
            p_time = res[2].strip()
            source = res[0].strip()
            content = response.css(".conzt ").extract()
            txt = response.css(".conzt ::text").extract()
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = '中国建筑材料联合会'
            item['cname'] = name
            item['title'] = title
            item['txt'] = txt
            item['p_time'] =get_times(p_time)
            item['source'] = source.split("：")[-1]
            item['content'] = ''.join(content)
            item['spider_name'] = 'cbmf'
            item['module_name'] = '行业新闻'
            yield item
        else:
            item['ctype'] = 3
            title = response.xpath("//table[@class='normal']/tbody/tr[1]/td/h1//text()").extract_first()
            res = response.xpath("//table[@class='normal']/tbody/tr[3]/td//text()").extract()
            p_time = res[2].strip()
            source = res[0].strip()
            content = response.css(".conzt ").extract()
            txt = response.css(".conzt ::text").extract()
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['lyurl'] = lyurl
            item['lyname'] = '中国建筑材料联合会'
            item['cname'] = name
            item['title'] = title
            item['p_time'] =get_times(p_time)
            item['source'] = source.split("：")[-1]
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cbmf'
            item['module_name'] = '行业协会'
            yield item