# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class XamdSpider(CrawlSpider):
    # 厦门市医疗器械行业协会
    name = 'xamd'
    allowed_domains = ['xamd.org']
    start_urls = ['http://www.xamd.org/market-148-4.aspx']

    rules = (
        Rule(LinkExtractor(allow=r'market-148-\d+.aspx$'), follow=True),
        Rule(LinkExtractor(allow=r'show-\d+.aspx$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='caboul']/div[@class='tlics']/text()").extract_first()
        p_time = response.xpath("//div[@class='folos tc']/span[@class='s1'][1]/text()").extract_first()
        content = response.css(".conlme  ").extract()
        txt = response.css(".conlme ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '厦门市医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = self.name
        item['source'] = ''
        item['ctype'] = 1
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['p_time'] =get_times(p_time)
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'xamd'
        item['module_name'] = '行业协会'
        yield item
