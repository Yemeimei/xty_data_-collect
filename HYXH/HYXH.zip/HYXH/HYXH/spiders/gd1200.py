# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class Sd1200Spider(CrawlSpider):
    # 广东省医疗器械行业协会
    name = 'gd1200'
    allowed_domains = ['1200.org.cn']
    start_urls = ['http://www.1200.org.cn/News.aspx?cid=1']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }
    rules = (
        Rule(LinkExtractor(allow=r'cid=\d+$'), follow=True),
        Rule(LinkExtractor(allow=r'ID=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        if response.url != 'http://www.1200.org.cn/Nmodify.aspx?ID=10':
            title = response.xpath("//div[@id='dds']/div[2]/h2/text()").extract_first()
            p_time = response.xpath("//div[@id='dds']/div[2]/text()").extract_first()
            content = response.css("#dds ").extract()
            txt = response.css("#dds ::text").extract()
            item = HyxhItem()
            lyurl = response.url
            lyname = '广东省医疗器械行业协会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['title'] = title
            item['source'] = ''
            item['ctype'] = 1
            item['p_time'] =get_times(p_time)
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'gd1200'
            item['module_name'] = '行业协会'
            yield item

