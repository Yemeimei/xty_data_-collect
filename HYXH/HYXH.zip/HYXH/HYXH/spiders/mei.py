# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule, Spider

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class MeiSpider(Spider):
    # 中国机械工业联合会
    name = 'mei'
    allowed_domains = ['mei.net.cn']
    start_urls = ['http://feature.mei.net.cn/meilist.asp', 'http://feature.mei.net.cn/view/more5.asp']

    def start_requests(self):
        for x in range(1, 1121):
            url = f'http://feature.mei.net.cn/meilist.asp?PG={x}'
            yield self.make_requests_from_url(url)
        for x in range(1, 246):
            url = f'http://feature.mei.net.cn/view/more5.asp?PG={x}'
            yield self.make_requests_from_url(url)

    # rules = (
    #     Rule(LinkExtractor(allow=r'keyword=\d+$'), callback='parse_item', follow=True),
    # )
    def parse(self, response):
        name = response.xpath("//tr[1]/td[@class='bei14b']/font//text()").extract_first()
        # print(name)
        urls = response.css('form[name="frmcx"] a::attr(href)').extract()
        for url in urls:
            yield scrapy.Request(response.urljoin(url), callback=self.parse_item, meta={'name': name})

    def parse_item(self, response):
        try:
            item = HyxhItem()
            name = response.meta['name']
            if name:
                item['ctype'] = 2
            else:
                item['ctype'] = 1
            title = response.xpath("//h1/font[@class='Blue']/text()").extract_first()
            p_time = response.css(".blackborder ::text").extract()
            content = response.css(".p12 ").extract()
            txt = response.css(".p12 ::text").extract()
            lyurl = response.url
            lyname = '中国机械工业联合会'
            txt = re.sub(r'\r+', '', ''.join(txt))
            txt = re.sub(r'\n+', '', txt)
            txt = re.sub(r'\t+', '', txt)
            txt = re.sub(r'(\u3000)+', '', txt)
            txt = re.sub(r'\xa0', '', txt)
            txt = re.sub(r' ', '', txt)
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['cname'] = self.name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['title'] = title
            item['source'] = p_time[30].strip().split(" ")[-1].strip().split("：")[-1]
            item['p_time'] =get_times(p_time)
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'mei'
            item['module_name'] = '行业协会'
            yield item
        except:
            pass
