# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments


class SmianetSpider(CrawlSpider):
    # 上海医疗器械行业协会
    name = 'smianet'
    allowed_domains = ['smianet.com']
    start_urls = ['http://www.smianet.com/Page.aspx?Id=7']

    # rules = (
    #     Rule(LinkExtractor(allow=r''), callback='parse_item', follow=True),
    # )

    def start_requests(self):
        param = {
            '__VIEWSTATE': '/wEPDwUKMTEzMzUyNzYwNw9kFgICAQ9kFggCAQ9kFgICBQ88KwAJAQAPFgQeCERhdGFLZXlzFgAeC18hSXRlbUNvdW50AhRkFihmD2QWBGYPFQEKSW5kZXguYXNweGQCAg8VAQzpppbjgIDjgIDpobVkAgIPZBYEZg8VAQwuL1BuZXdzLmFzcHhkAgIPFQEM5Zu+54mH5paw6Ze7ZAIED2QWBGYPFQEOUGFnZS5hc3B4P0lkPTRkAgIPFQEM5Y2P5Lya5bel5L2cZAIGD2QWBGYPFQEJLi9qeC5hc3B4ZAICDxUBDOeugOOAgOOAgOiur2QCCA9kFgRmDxUBCS4vbGouYXNweGQCAg8VAQ3lubTjgIAg44CA6Ym0ZAIKD2QWBGYPFQEPUGFnZS5hc3B4P0lkPTMxZAICDxUBDOS4k+WutuiuuuWdm2QCDA9kFgRmDxUBLmh0dHA6Ly93d3cuNWlwYXRlbnQuY29tL2NuLzVpLTIveWxxeC9pbmRleC5hc3BkAgIPFQEM5LiT5Yip5p+l6K+iZAIOD2QWBGYPFQEPUGFnZS5hc3B4P0lkPTI3ZAICDxUBDOe7vOWQiOS/oeaBr2QCEA9kFgRmDxUBDlBhZ2UuYXNweD9JZD03ZAICDxUBDOihjOS4mui1hOiur2QCEg9kFgRmDxUBDlBhZ2UuYXNweD9JZD01ZAICDxUBDOW4guWcuuS/oeaBr2QCFA9kFgRmDxUBDlBhZ2UuYXNweD9JZD0zZAICDxUBDOebkeeuoeWKqOaAgWQCFg9kFgRmDxUBD1BhZ2UuYXNweD9JZD0yOGQCAg8VAQzmi5vmoIfkv6Hmga9kAhgPZBYEZg8VAQ5QYWdlLmFzcHg/SWQ9MmQCAg8VAQzmlL/nrZbms5Xop4RkAhoPZBYEZg8VAQ9QYWdlLmFzcHg/SWQ9NDBkAgIPFQEM5Lya5ZGY5Yqo5oCBZAIcD2QWBGYPFQEPUGFnZS5hc3B4P0lkPTI5ZAICDxUBDemAmuefpS/lkK/npLpkAh4PZBYEZg8VARVqZ2dsLmFzcHg/SWQ9NDIsNDMsNDRkAgIPFQEM5Lu35qC8566h55CGZAIgD2QWBGYPFQEPUGFnZS5hc3B4P0lkPTMwZAICDxUBDOWxleS8muS/oeaBr2QCIg9kFgRmDxUBG2h0dHA6Ly90cmFpbmluZy5zbWlhbmV0LmNvbWQCAg8VAQzmlZnogrLln7norq1kAiQPZBYEZg8VAQ1Kb2JJbmRleC5hc3B4ZAICDxUBDOS6uuaJjeS6pOa1gWQCJg9kFgRmDxUBD1BhZ2UuYXNweD9JZD0zNWQCAg8VAQzkvpvmsYLkv6Hmga9kAgMPDxYCHgRUZXh0BQzooYzkuJrotYTorq9kZAIFDzwrAAkBAA8WBB8AFgAfAQIeZBY8Zg9kFgJmDxUDBTM1MDQ1RuenkeWtpuWutiAzRCDnlJ/nianmiZPljbDlpKfohJHmqKHlnovnlKjkuo7noJTnqbbnpZ7nu4/pgIDooYzmgKfnlr7nl4URWzIwMTjlubQz5pyINuaXpV1kAgEPZBYCZg8VAwUzNTA0NirlpJrlrrblmajmorDkvIHkuJrkuLvliqjlj6zlm57nm7jlhbPkuqflk4ERWzIwMTjlubQz5pyINuaXpV1kAgIPZBYCZg8VAwUzNTAzMTJGREHmibnlh4bnvo7lm73pppbkuKoxLjBtbeWGoOeKtuWKqOiEieeQg+WbiuS4iuW4ghFbMjAxOOW5tDPmnIg15pelXWQCAw9kFgJmDxUDBTM1MDM1NuWTiOS9m+Wkp+WtpueglOeptuS6uuWRmOWIm+mAoOS6huS4gOenjeeUteWtkOWBh+ecvCAgIBFbMjAxOOW5tDPmnIg15pelXWQCBA9kFgJmDxUDBTM1MDM3SeaIkeWbveeglOWItuWujOaIkOi0qOWtkOayu+eWl+aguOW/g+mDqOS7tiDmnKrmnaXmnInmnJvpgKDnpo/nmYznl4fmgqPogIURWzIwMTjlubQz5pyINeaXpV1kAgUPZBYCZg8VAwUzNTAyMjlDb2dub2Hkurrlt6Xmmbrog73lubPlj7DojrdGREHmibnlh4bnlKjkuo7oh6rpl63nl4fnrZvmn6URWzIwMTjlubQz5pyIMeaXpV1kAgYPZBYCZg8VAwUzNTAwNSpGREHpppbmrKHnu5nohJHpnIfojaHooYDmo4Dlt6XlhbflvIDnu7/nga8SWzIwMTjlubQy5pyIMjjml6VdZAIHD2QWAmYPFQMFMzQ5OTMe5Lik6aG5SVZE56CU5Y+R5oiQ5p6c6I636IKv5a6aElsyMDE45bm0MuaciDI25pelXWQCCA9kFgJmDxUDBTM0OTk0QumAj+awlOWPr+epv+aItOearuiCpOS8oOaEn+WZqO+8jOacquadpeeUqOS6jumVv+acn+eahOWBpeW6t+ebkea1ixJbMjAxOOW5tDLmnIgyNuaXpV1kAgkPZBYCZg8VAwUzNDk4OTPmlrDlnovnlLXlrZDnmq7ogqTvvIzlj6/oh6rooYzkv67lpI3lj6/lvqrnjq/liKnnlKgSWzIwMTjlubQy5pyIMTPml6VdZAIKD2QWAmYPFQMFMzQ5ODQ3RkRBIOaJueWHhummluS4queZq+eXq+WPkeS9nOebkea1i+eUqOaZuuiDveepv+aItOiuvuWkhxJbMjAxOOW5tDLmnIgxMuaXpV1kAgsPZBYCZg8VAwUzNDk3OS3otKjlrZDmsrvnmYzliqDpgJ/lmajmoLjlv4Ppg6jku7bnoJTliLblrozmiJARWzIwMTjlubQy5pyIOeaXpV1kAgwPZBYCZg8VAwUzNDk3MS3lj6/lkLjmlLbnoazohJHohpzlsIHlkIjljLvnlKjog7bojrfmibnkuIrluIIRWzIwMTjlubQy5pyIN+aXpV1kAg0PZBYCZg8VAwUzNDk2OC3lm5vlt53pppbkuKrnrKzkuoznsbvliJvmlrDlmajmorDpgJrov4forqTlrpoRWzIwMTjlubQy5pyIN+aXpV1kAg4PZBYCZg8VAwUzNDk1OUXkuK3moLjpm4blm6LmiJDlip/lrozmiJDotKjlrZDmsrvnmYzliqDpgJ/lmajlhajpg6jmoLjlv4Ppg6jku7bnoJTliLYRWzIwMTjlubQy5pyIMuaXpV1kAg8PZBYCZg8VAwUzNDk2MCrkurrlt6Xmmbrog73mo4DmtYvog4PnmYzloKrmr5Tnhp/nu4PljLvnlJ8RWzIwMTjlubQy5pyIMuaXpV1kAhAPZBYCZg8VAwUzNDk0NTbigJzmlbDlrZdQRVTigJ3ojrflm73lrrbliJvmlrDljLvnlpflmajmorDnibnliKvlrqHmibkSWzIwMTjlubQx5pyIMzHml6VdZAIRD2QWAmYPFQMFMzQ5NDcw5p6B566A5py65Zmo5Lq65bCG5Y+v5Zyo6Lqr5L2T5YaF6YOo4oCc5beh6YC74oCdElsyMDE45bm0MeaciDMx5pelXWQCEg9kFgJmDxUDBTM0OTM3LemAmueUqOeUteawlOetieS8geS4muS4u+WKqOWPrOWbnuWZqOaisOS6p+WTgRJbMjAxOOW5tDHmnIgzMOaXpV1kAhMPZBYCZg8VAwUzNDkzOEHnoJTnqbbooajmmI7vvIwzROaJk+WNsOmSm+e9keakjeWFpeeJqeacieWIqeS6juaCo+iAhemqqOmqvOWGjeeUnxJbMjAxOOW5tDHmnIgzMOaXpV1kAhQPZBYCZg8VAwUzNDkzMDDnp5HlrablrrbmraPnoJTlj5Hlj6/mo4DmtYvooYDns5bnmoTpmpDlvaLnnLzplZwSWzIwMTjlubQx5pyIMjnml6VdZAIVD2QWAmYPFQMFMzQ5MjAu56eR5a2m5a626YCg5Ye65Y+v6auY6YCf6L+Q5Yqo55qERE5BIOacuuaisOiHghJbMjAxOOW5tDHmnIgyNeaXpV1kAhYPZBYCZg8VAwUzNDg5Ny3msLTlh53og7bnlJ/nianmnZDmlpnmnInmnJvmsrvnlpfogozogonmjZ/kvKQSWzIwMTjlubQx5pyIMjLml6VdZAIXD2QWAmYPFQMFMzQ4ODVB6L+Z56eN5paw5Z6L5L2O5ripM0TmiZPljbDvvIzkuqflk4Hlj6/mqKHku7/lpKfohJHlkozogrrpg6jnibnmgKcSWzIwMTjlubQx5pyIMTjml6VdZAIYD2QWAmYPFQMFMzQ4NzIxIOWPr+i/vei4queZjOe7huiDnueahOaZuuiDveW+rue6s+acuuWZqOS6uumXruS4lhJbMjAxOOW5tDHmnIgxN+aXpV1kAhkPZBYCZg8VAwUzNDg1NCYyMOS9meWutuWZqOaisOS8geS4muS4u+WKqOWPrOWbnuS6p+WTgRJbMjAxOOW5tDHmnIgxNuaXpV1kAhoPZBYCZg8VAwUzNDg1NUrlm73lhoXpppbkuKozROaJk+WNsOmZtueTt+S5iem9v+iOt+W+l+WMu+eWl+WZqOaisOazqOWGjOivgeWPr+S4iuW4gumUgOWUrhJbMjAxOOW5tDHmnIgxNuaXpV1kAhsPZBYCZg8VAwUzNDg1Mz/msJTkvZPkvKDmhJ/lmajigJzoja/kuLjigJ3orqnppa7po5/lgaXlurfnrqHnkIbkuI3lho3mmK/pmr7popgSWzIwMTjlubQx5pyIMTLml6VdZAIcD2QWAmYPFQMFMzQ4NDU/5Yeg5ZCo6YeN55qE5qC456OB5YWx5oyv5Luq77yM57yp5bCP5Yiw56yU6K6w5pys55S16ISR5LiA5qC35aSnElsyMDE45bm0MeaciDEx5pelXWQCHQ9kFgJmDxUDBTM0ODI3P+S7peiJsuWIl+WMu+mZouWujOaIkOmmluS+i+W/g+ihsOayu+eWl+ijhee9ruS6uuS9k+akjeWFpeaJi+acrxFbMjAxOOW5tDHmnIg55pelXWQCBw8PFggeDVNob3dQYWdlSW5kZXhoHgtSZWNvcmRjb3VudALcLx4OQ3VzdG9tSW5mb1RleHQFlgHlhbE8Zm9udCBjb2xvcj0iYmx1ZSI+NjEwODwvZm9udD7mnaHmlrDpl7sg6aG15qyh77yaPGZvbnQgY29sb3I9ImJsdWUiPjk8L2ZvbnQ+Lzxmb250IGNvbG9yPSJibHVlIj4yMDQ8L2ZvbnQ+IDxmb250IGNvbG9yPSJyZWQiPjMwPC9mb250PuadoeaWsOmXuy/pobUeEEN1cnJlbnRQYWdlSW5kZXgCCWRkZO+dmFjR5nGScHBF5AMC9tA3HQ1R',
            '__VIEWSTATEGENERATOR': '3989C74E',
            '__EVENTTARGET': 'AspNetPager1',
            '__EVENTARGUMENT': '1',
            'AspNetPager1_input': '3'
        }
        url = 'http://www.smianet.com/Page.aspx?Id=7'
        yield scrapy.FormRequest(url=url, formdata=param, callback=self.parse)

    def parse(self, response):
        par = response.css("#__VIEWSTATE ::attr(value)").extract_first()
        urls = response.css("#DatalistDetails a::attr(href)").extract()
        for url in urls:
            url = 'http://www.smianet.com/' + url
            yield scrapy.Request(url=url, callback=self.parse_item)
        # print(par)
        page = response.xpath("//div[@id='AspNetPager1']//td[1]/font[2]/text()").extract_first()
        param = {
            '__VIEWSTATE': par,
            '__VIEWSTATEGENERATOR': '3989C74E',
            '__EVENTTARGET': 'AspNetPager1',
            '__EVENTARGUMENT': str(int(page) + 1),
            'AspNetPager1_input': '1'
        }
        url = 'http://www.smianet.com/Page.aspx?Id=7'
        # print(param)
        yield scrapy.FormRequest(url=url, formdata=param, callback=self.parse)

    def parse_item(self, response):
        title = response.css("#lblTitle ::text").extract_first()
        content = response.css("#ContentDiv ").extract()
        txt = response.css("#ContentDiv ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '上海医疗器械行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['cname'] = self.name
        item['title'] = title
        item['ctype'] = 1
        source = txt.split("（", -1)[-1].replace('）', '')
        item['source'] = source
        if len(source) > 20:
            item['source'] = ''
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['appendix'] = appendix
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['spider_name'] = 'smianet'
        item['module_name'] = '行业协会'
        yield item