# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments, get_times


class CansiSpider(CrawlSpider):
    # 中国船舶工业行业协会
    name = 'cansi'
    allowed_domains = ['cansi.org.cn']
    start_urls = ['http://www.cansi.org.cn/news/news.php?lang=cn&class1=166&page=1',
                  'http://www.cansi.org.cn/ifor/news.php?lang=cn&class2=185',
                  'http://www.cansi.org.cn/ifor/news.php?lang=cn&class2=186']
    custom_settings = {
        'CONCURRENT_REQUESTS': 10,
        'CONCURRENT_REQUESTS_PER_DOMAIN': 10,
        'CONCURRENT_REQUESTS_PER_IP': 0,
        'DOWNLOAD_DELAY': 0.5,
        'ITEM_PIPELINES': {
            'HYXH.pipelines.MysqlTwistedPipeline': 600,
            # 'HYXH.pipelines.DuplicatesPipeline': 200,
        },
        # 'SPIDER_MIDDLEWARES': {
        #     'scrapy_splash.SplashDeduplicateArgsMiddleware': 100,
        # },
        'DOWNLOADER_MIDDLEWARES': {
            # 'scrapy_splash.SplashCookiesMiddleware': 723,
            # 'scrapy_splash.SplashMiddleware': 725,
            'scrapy.downloadermiddlewares.httpproxy.HttpProxyMiddleware': 700,
            # 'HYXH.util_custom.middleware.middlewares.ProxyMiddleWare': 100,

            'scrapy.downloadermiddlewares.useragent.UserAgentMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyUserAgentMiddleware': 120,

            'scrapy.downloadermiddlewares.retry.RetryMiddleware': None,
            'HYXH.util_custom.middleware.middlewares.MyRetryMiddleware': 90,
        },
        # 'DUPEFILTER_CLASS': 'scrapy_splash.SplashAwareDupeFilter',
        # # 'SPLASH_URL': "http://10.8.32.122:8050/"
        # 'SPLASH_URL': "http://127.0.0.1:8050/"
    }

    rules = (
        Rule(LinkExtractor(allow=r'page=\d+'), follow=True),
        Rule(LinkExtractor(allow=r'id=\d+'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        name = response.xpath("//div[@class='right01']/span/a[3]/text()").extract_first()
        title = response.xpath("//div[@class='right03']/div[@class='right0601']/text()").extract_first()
        p_time = response.xpath("//div[@class='right03']/div[@class='from']/span[1]/text()").extract_first()
        content = response.css(".right03 ").extract()
        txt = response.css(".right03 ::text").extract()
        item = HyxhItem()
        ctype = response.xpath("//div[@id='main-right']/div[@class='right01']/span/a[3]//text()").extract_first()
        lyurl = response.url
        lyname = '中国船舶工业行业协会'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        if ctype == '统计数据':
            item['ctype'] = 2
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            item['source'] = ''
            item['cname'] = name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cansi'
            item['module_name'] = '行业协会'
            item['p_time'] =get_times(p_time)
            yield item

        elif ctype == '运行分析':
            item['ctype'] = 3
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            item['source'] = ''
            item['cname'] = name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cansi'
            item['module_name'] = '行业协会'
            item['p_time'] =get_times(p_time)
            yield item

        elif response.xpath("//div[@id='main-right']/div[@class='right01']/span/a[2]//text()").extract_first() == '新闻中心':
            item['ctype'] = 1
            item['lyurl'] = lyurl
            item['lyname'] = lyname
            item['title'] = title
            item['source'] = ''
            item['cname'] = name
            appendix, appendix_name = get_attachments(response)
            item['appendix'] = appendix
            item['appendix_name'] = appendix_name
            item['content'] = ''.join(content)
            item['txt'] = txt
            item['spider_name'] = 'cansi'
            item['module_name'] = '行业协会'
            item['p_time'] =get_times(p_time)
            yield item

