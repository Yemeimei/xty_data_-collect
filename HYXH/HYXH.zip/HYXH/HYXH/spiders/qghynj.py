# -*- coding: utf-8 -*-
import re

import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule

from HYXH.items import QghynjItem, HyxhItem
from HYXH.util_custom.tools.attachment import get_attachments


class QghynjSpider(CrawlSpider):
    # 中国船舶行业年鉴
    name = 'qghynj'
    allowed_domains = ['cansi.org.cn']
    start_urls = ['http://www.cansi.org.cn/bjmk/img.php?lang=cn&class2=205']

    rules = (
        Rule(LinkExtractor(allow=r'', restrict_css='.PreSpan'), follow=True),
        Rule(LinkExtractor(allow=r'id=\d+$'), callback='parse_item', follow=True),
    )

    def parse_item(self, response):
        title = response.xpath("//div[@class='has honor cb_titile']/ul/li/a/text()").extract_first()
        content = response.css(".list-paddingleft-2 ").extract()
        txt = response.css(".list-paddingleft-2 ::text").extract()
        item = HyxhItem()
        lyurl = response.url
        lyname = '中国船舶行业年鉴'
        txt = re.sub(r'\r+', '', ''.join(txt))
        txt = re.sub(r'\n+', '', txt)
        txt = re.sub(r'\t+', '', txt)
        txt = re.sub(r'(\u3000)+', '', txt)
        txt = re.sub(r'\xa0', '', txt)
        txt = re.sub(r' ', '', txt)
        appendix, appendix_name = get_attachments(response)
        item['appendix'] = appendix
        item['appendix_name'] = appendix_name
        item['lyurl'] = lyurl
        item['lyname'] = lyname
        item['title'] = title
        item['cname'] = self.name
        item['content'] = ''.join(content)
        item['txt'] = txt
        item['source'] = ''
        item['p_time'] = ''
        item['ctype'] = 1
        item['spider_name'] = 'qghynj'
        item['module_name'] = '行业协会'
        yield item